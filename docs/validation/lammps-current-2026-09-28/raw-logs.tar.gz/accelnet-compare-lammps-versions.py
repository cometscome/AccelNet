from pathlib import Path
import json,re
import numpy as np

def dump(path):
 lines=path.read_text().splitlines();start=next(i for i,x in enumerate(lines) if x.startswith('ITEM: ATOMS'))+1
 return np.array([list(map(float,x.split())) for x in lines[start:]])
def thermo(path):
 rows=[]
 for line in path.read_text().splitlines():
  fields=line.split()
  if len(fields)==8 and re.fullmatch(r'\d+',fields[0]):
   try: rows.append(list(map(float,fields)))
   except ValueError:pass
 return np.array(rows)
report=[]
for version in ('stable','rc'):
 for case in ('orthogonal','triclinic','empty'):
  for mode in ('auto','direct','moment'):
   name=f'{case}-{mode}-cpu-1rank'
   base=Path('/tmp/accelnet-lammps-current-2024-cpu-check')/name
   new=Path(f'/tmp/accelnet-lammps-current-{version}-cpu-check')/name
   a,b=thermo(base/'stdout.txt'),thermo(new/'stdout.txt')
   np.testing.assert_allclose(a,b,atol=2e-5,rtol=2e-9)
   row=dict(version=version,case=case,mode=mode,total_energy=float(np.max(np.abs(a[:,1]-b[:,1]))),virial_pressure=float(np.max(np.abs(a[:,2:]-b[:,2:]))))
   for snapshot in ('initial','final'):
    a,b=dump(base/(snapshot+'.dump')),dump(new/(snapshot+'.dump'))
    np.testing.assert_allclose(a[:,:2],b[:,:2],atol=0,rtol=0)
    np.testing.assert_allclose(a[:,2:],b[:,2:],atol=2e-8,rtol=2e-9)
    row[snapshot]=dict(force=float(np.max(np.abs(a[:,5:8]-b[:,5:8]))),atom_energy=float(np.max(np.abs(a[:,8]-b[:,8]))),position=float(np.max(np.abs(a[:,2:5]-b[:,2:5]))))
   report.append(row)
Path('/tmp/accelnet-lammps-current-cpu-cross-version.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'{len(report)} cross-version CPU comparisons passed')
for version in ('stable','rc'):
 rows=[r for r in report if r['version']==version]
 print(version,'max force error',max(r[s]['force'] for r in rows for s in ('initial','final')),'max energy error',max(r['total_energy'] for r in rows))
