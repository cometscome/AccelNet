from pathlib import Path
import re,shutil
repo=Path('/home/nagai/AccelNetGPU/AccelNet-clone')
here=repo/'interfaces/lammps/29Aug2024'
for release in ('stable','rc'):
 root=Path('/tmp/accelnet-lammps-current-'+release)
 for src,dst in [('ACCELNET','src/ACCELNET'),('GPU','src/GPU'),('lib-gpu','lib/gpu')]:
  shutil.copytree(here/src,root/dst,dirs_exist_ok=True)
 for name in ['accelnet.h','accelnet_target.h']:
  shutil.copy(repo/'AccelNetPredictor/include'/name,root/'src/ACCELNET'/name)
 shutil.copy(here/'cmake/ACCELNET.cmake',root/'cmake/Modules/Packages/ACCELNET.cmake')
 p=root/'cmake/CMakeLists.txt';s=p.read_text()
 s=s.replace('set(STANDARD_PACKAGES\n','set(STANDARD_PACKAGES\n  ACCELNET\n',1)
 s,n=re.subn(r'foreach\(PKG_WITH_INCL ([^\n]*KSPACE)',r'foreach(PKG_WITH_INCL ACCELNET \1',s,count=1)
 assert n==1
 p.write_text(s)
 p=root/'src/atom.cpp';s=p.read_text();old='#ifdef LMP_GPU\n  if (userbinsize == 0.0) {'
 print(release,'old triclinic sorting guard matches',s.count(old))
 if old in s:p.write_text(s.replace(old,'#ifdef LMP_GPU\n  if (userbinsize == 0.0 && !domain->triclinic) {'))
